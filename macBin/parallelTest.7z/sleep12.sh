#!/bin/bash
TIME_TO_SLEEP=12
echo ""
DATE=`date`
echo "-> $0 $TIME_TO_SLEEP: $DATE"
sleep $TIME_TO_SLEEP
DATE=`date`
echo "<- $0 $TIME_TO_SLEEP: $DATE"
echo ""
