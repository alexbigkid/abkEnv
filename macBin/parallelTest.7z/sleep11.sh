#!/bin/bash
TIME_TO_SLEEP=11
echo ""
DATE=`date`
echo "-> sleep $TIME_TO_SLEEP: $DATE"
sleep $TIME_TO_SLEEP
DATE=`date`
echo "<- sleep $TIME_TO_SLEEP: $DATE"
echo ""
